/*
Paso 1: Crear un constructor de la clase (public) private
Pase 2: Declarar una variable privada y estatica del formulario 
        que se requiere utilizar (JFrame)
Paso 3: Agregar la libreria 
Paso 4: Creamos un metodo para la instacia dle objeto
Paso 5: Agregar el paquete Login con su clase
*/
package org.jobsis.clases;

import javax.swing.JFrame;
import org.jobsis.system.Login;

public class LoginSingleton {
    private static JFrame log;
    
    private LoginSingleton() {
    }
    public static JFrame getInstance(){
        if (log == null)
            log = new Login();
        return log;
    }
    
    
}
